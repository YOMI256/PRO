﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arreglo = new int[10];
            int suma;
            suma = 0;

            Random rand = new Random();
            

            for (int i = 0; i < arreglo.Length; i++)
            {
                arreglo[i] = rand.Next(9);
                Console.WriteLine(arreglo[i]);
                suma = suma + arreglo[i];
            }

            Console.WriteLine("La suma del arreglo es {0}:", suma);
            Console.ReadKey();
        }
    }
}
