﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arreglo = new int[5];
            arreglo[0] = 7;
            arreglo[1] = 27;
            arreglo[2] = 87;
            arreglo[3] = 65;
            arreglo[4] = 21;

            Console.WriteLine("Arreglo desordenado:");
            for (int i = 0; i < arreglo.Length; i++)
            {
                Console.WriteLine(arreglo[i]);
            }

            Console.WriteLine(" ");
            Array.Sort(arreglo);
            Console.WriteLine("Arreglo ordenado");
            for (int i = 0; i < arreglo.Length; i++)
            {
                Console.WriteLine(arreglo[i]);
            }
            Console.ReadKey();
        }
    }
}
