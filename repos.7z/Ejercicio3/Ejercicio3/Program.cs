﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList numerolist = new ArrayList();
            int suma = 0;
            int cantidad = 0;

            Console.WriteLine("Ingrese la cantidad de numeros: ");
            cantidad = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <= cantidad - 1; i++)
            {
                Console.WriteLine("Ingrese sus valores: ");
                numerolist.Add(Convert.ToInt32(Console.ReadLine()));
                suma += Convert.ToInt32(numerolist[i]);
            }

            Console.WriteLine("La suma de sus valores es: {0}", suma);
            Console.ReadKey();
        }
    }
}
